/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controler;

import javax.swing.JOptionPane;
import model.MataKuliah;
import view.FormLihatMataKuliah;
import view.FormUtama;

/**
 *
 * @author Bagas Septian
 *
 */
public class MataKuliahController {
    private final MataKuliah mataKuliah = new MataKuliah();
    private FormLihatMataKuliah formLihatMataKuliah;
    
    public void simpan(javax.swing.JTextField jTextField1, 
            javax.swing.JTextField jTextField2,
            javax.swing.JComboBox jumlahSksComboBox){
        if (!jTextField1.getText().equals("")){
            mataKuliah.setKodeMataKuliah(jTextField1.getText());
            mataKuliah.setNamaMataKuliah(jTextField2.getText());
            mataKuliah.setJumlahSks(Integer.parseInt(
                    jumlahSksComboBox.getSelectedItem().toString()));
            
            if (mataKuliah.simpan()){
                FormUtama.formMataKuliah.setKodeMataKuliah("");
                FormUtama.formMataKuliah.setNamaMataKuliah("");
                FormUtama.formMataKuliah.setJumlahSks(1);
            }  else {
                if (mataKuliah.getPesan().length() > 0){
                    JOptionPane.showMessageDialog(null, mataKuliah.getPesan(), "Kesalahan", JOptionPane.ERROR_MESSAGE);
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "Kode mata kuliah tidak boleh kosong", "Kesalahan", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void hapus(javax.swing.JTextField jTextField1){
        if (!jTextField1.getText().equals("")){
            if (mataKuliah.hapus(jTextField1.getText())){
                FormUtama.formMataKuliah.setKodeMataKuliah("");
                FormUtama.formMataKuliah.setNamaMataKuliah("");
                FormUtama.formMataKuliah.setJumlahSks(1);
            }  else {
                JOptionPane.showMessageDialog(null, mataKuliah.getPesan(), "Kesalahan", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Kode mata kuliah tidak boleh kosong", "Kesalahan", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void cari(javax.swing.JTextField jTextField1){
        if (!jTextField1.getText().equals("")){
            if (mataKuliah.baca(jTextField1.getText())){
                FormUtama.formMataKuliah.setNamaMataKuliah(mataKuliah.getNamaMataKuliah());
                FormUtama.formMataKuliah.setJumlahSks(mataKuliah.getJumlahSks());
            } else {
                FormUtama.formMataKuliah.setNamaMataKuliah("");
                FormUtama.formMataKuliah.setJumlahSks(1);
                
                JOptionPane.showMessageDialog(null, mataKuliah.getPesan(), "Kesalahan", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Kode mata kuliah tidak boleh kosong", "Kesalahan", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void tampilkanDaftar(){
        formLihatMataKuliah = new FormLihatMataKuliah(null,true);
        if (mataKuliah.bacaData()){
            formLihatMataKuliah.tampilkanData(mataKuliah.getList());
            
            formLihatMataKuliah.setVisible(true);
            if (!formLihatMataKuliah.getKodeMataKuliahDipilih().equals("")){
                FormUtama.formMataKuliah.setKodeMataKuliah(formLihatMataKuliah.getKodeMataKuliahDipilih());
                if (mataKuliah.baca(formLihatMataKuliah.getKodeMataKuliahDipilih())){
                    FormUtama.formMataKuliah.setNamaMataKuliah(mataKuliah.getNamaMataKuliah());
                    FormUtama.formMataKuliah.setJumlahSks(mataKuliah.getJumlahSks());
                } else {
                    FormUtama.formMataKuliah.setNamaMataKuliah("");
                    FormUtama.formMataKuliah.setJumlahSks(1);
                }
            }
        }  else {
            JOptionPane.showMessageDialog(null, mataKuliah.getPesan());
        }
    }
}
