/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controler;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import model.Enkripsi;
import model.Mahasiswa;
import view.FormLihatMahasiswa;
import view.FormUtama;

/**
 *
 * @author Bagas Septian
 */
public class MahasiswaController {
    private final Mahasiswa mahasiswa = new Mahasiswa();
    private FormLihatMahasiswa formLihatMahasiswa;
    private final Enkripsi enkripsi = new Enkripsi();
    private boolean hashed = false;

    public void setHashed(boolean hashed) {
        this.hashed = hashed;
    }
    
    public void simpan(javax.swing.JTextField jTextField1, javax.swing.JTextField jTextField2,
            javax.swing.JComboBox jComboBox1, javax.swing.JComboBox jComboBox2, javax.swing.JPasswordField jpasswordField1){
        if (!jTextField1.getText().equals("")){
            mahasiswa.setNim(jTextField1.getText());
            mahasiswa.setNama(jTextField2.getText());
            mahasiswa.setSemester(Integer.parseInt(jComboBox1.getSelectedItem().toString()));
            mahasiswa.setKelas(jComboBox2.getSelectedItem().toString());
            
            if (hashed){
                mahasiswa.setPassword(new String(jpasswordField1.getPassword()));
            } else {
                try {
                    mahasiswa.setPassword(enkripsi.hashMD5(new String(jpasswordField1.getPassword())));
                } catch (Exception ex){
                    mahasiswa.setPassword("");
                }
            }
            
            if (mahasiswa.simpan()){
                FormUtama.formMahasiswa.setNim("");
                FormUtama.formMahasiswa.setNama("");
                FormUtama.formMahasiswa.setSemester(1);
                FormUtama.formMahasiswa.setKelas("A");
                FormUtama.formMahasiswa.setPassword("");
            }  else {
                if (mahasiswa.getPesan().length() > 0){
                    JOptionPane.showMessageDialog(null, mahasiswa.getPesan(), "Kesalahan", JOptionPane.ERROR_MESSAGE);
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "NIM tidak boleh kosong", "Kesalahan", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void hapus(javax.swing.JTextField jTextField1){
        if (!jTextField1.getText().equals("")){
            if (mahasiswa.hapus(jTextField1.getText())){
                FormUtama.formMahasiswa.setNim("");
                FormUtama.formMahasiswa.setNama("");
                FormUtama.formMahasiswa.setSemester(1);
                FormUtama.formMahasiswa.setKelas("A");
                FormUtama.formMahasiswa.setPassword("");
            }else {
                JOptionPane.showMessageDialog(null, mahasiswa.getPesan(), "Kesalahan", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "NIM tidak boleh kosong", "Kesalahan", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void cari(javax.swing.JTextField jTextField1){
        if (!jTextField1.getText().equals("")){
            if (mahasiswa.baca(jTextField1.getText())){
                FormUtama.formMahasiswa.setNama(mahasiswa.getNama());
                FormUtama.formMahasiswa.setSemester(mahasiswa.getSemester());
                FormUtama.formMahasiswa.setKelas(mahasiswa.getKelas());
                FormUtama.formMahasiswa.setPassword(mahasiswa.getPassword());
                hashed = true;
            } else {
                FormUtama.formMahasiswa.setNama("");
                FormUtama.formMahasiswa.setSemester(1);
                FormUtama.formMahasiswa.setKelas("A");
                FormUtama.formMahasiswa.setPassword("");
                
                JOptionPane.showMessageDialog(null, mahasiswa.getPesan(), "Kesalahan", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "NIM tidak boleh kosong", "Kesalahan", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void tampilkanFormLihatMahasiswa(){
        formLihatMahasiswa = new FormLihatMahasiswa(null,true);
        
        if (mahasiswa.bacaData()){
            formLihatMahasiswa.tampilkanData(mahasiswa.getList());
            
            formLihatMahasiswa.setVisible(true);
            if (!formLihatMahasiswa.getNimDipilih().equals("")){
                FormUtama.formMahasiswa.setNim(formLihatMahasiswa.getNimDipilih());
                if (mahasiswa.baca(formLihatMahasiswa.getNimDipilih())){
                    FormUtama.formMahasiswa.setNama(mahasiswa.getNama());
                    FormUtama.formMahasiswa.setSemester(mahasiswa.getSemester());
                    FormUtama.formMahasiswa.setKelas(mahasiswa.getKelas());
                    FormUtama.formMahasiswa.setPassword(mahasiswa.getPassword());
                    hashed = true;
                } else {
                    FormUtama.formMahasiswa.setNama("");
                    FormUtama.formMahasiswa.setSemester(1);
                    FormUtama.formMahasiswa.setKelas("A");
                    FormUtama.formMahasiswa.setPassword("");
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, mahasiswa.getPesan());
        }
    }
}

