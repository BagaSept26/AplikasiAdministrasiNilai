/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controler;

import javax.swing.JOptionPane;
import model.Mahasiswa;
import model.MataKuliah;
import model.Nilai;
import view.FormLihatMahasiswa;
import view.FormLihatMataKuliah;
import view.FormUtama;
import view.FormNilai;
import view.FormMhs;

/**
 *
 * @author Bagas Septian
 */
public class NilaiController {
    private final Mahasiswa mahasiswa = new Mahasiswa();
    private final MataKuliah mataKuliah = new MataKuliah();
    private final Nilai nilai = new Nilai();
    private FormLihatMahasiswa formLihatMahasiswa;
    private FormLihatMataKuliah formLihatMataKuliah;
    private FormNilai formNilai;
    private FormUtama formUtama;
    private FormMhs formMhs;
    
    
    public void cariMahasiswa(javax.swing.JTextField nim){
        if (!nim.getText().equals("")){
            if (mahasiswa.baca(nim.getText())){
                FormUtama.formNilai.setNama(mahasiswa.getNama());
                FormUtama.formNilai.setSemester( Integer.toString( mahasiswa.getSemester()));
                FormUtama.formNilai.setKelas(mahasiswa.getKelas());
                FormUtama.formNilai.clearjTable1();
                
                int jumlahNilai=0;
                if (nilai.baca(nim.getText())){
                    Object[][] listNilai = nilai.getListNilai();
                    FormUtama.formNilai.clearjTable1();
                    
                    if (listNilai.length>0){
                        for (int i=0; i<listNilai.length;i++){
                            if (!((String)listNilai[i][0]).equals("")){
                                String namaMataKuliah="";
                                if (mataKuliah.baca((String) listNilai[i][0])){
                                    namaMataKuliah = mataKuliah.getNamaMataKuliah();                      
                                }
                                FormUtama.formNilai.setTambahNilai(new Object[]{listNilai[i][0],namaMataKuliah,listNilai[i][1],listNilai[i][2],listNilai[i][3]});
                                jumlahNilai++;
                            }
                        }
                    }
                } 
                
                if (jumlahNilai==0) {
                    FormUtama.formNilai.setTambahNilai(new Object[]{});
                }
            } else {
                FormUtama.formNilai.setNama("");
                FormUtama.formNilai.setSemester("");
                FormUtama.formNilai.setKelas("");
                FormUtama.formNilai.clearjTable1();
                FormUtama.formNilai.setTambahNilai(new Object[]{});
                
                JOptionPane.showMessageDialog(null, mahasiswa.getPesan(), "Kesalahan", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null,"nim tidak boleh kosong\n","Kesalahan",JOptionPane.ERROR_MESSAGE);
        } 
    }
    
    public void tampilkanFormLihatMahasiswa(){
        formLihatMahasiswa = new FormLihatMahasiswa(null, true);
        if (mahasiswa.bacaData()){
            formLihatMahasiswa.tampilkanData(mahasiswa.getList());
            formLihatMahasiswa.setVisible(true);
            
            if (!formLihatMahasiswa.getNimDipilih().equals("")) {
                if (mahasiswa.baca(formLihatMahasiswa.getNimDipilih())){
                    FormUtama.formNilai.setNim(mahasiswa.getNim());
                    FormUtama.formNilai.setNama(mahasiswa.getNama());
                    FormUtama.formNilai.setSemester( Integer.toString( mahasiswa.getSemester()));
                    FormUtama.formNilai.setKelas(mahasiswa.getKelas());
                    FormUtama.formNilai.clearjTable1();
                    
                    int jumlahNilai=0;
                    if (nilai.baca(formLihatMahasiswa.getNimDipilih())){
                        Object[][] listNilai = nilai.getListNilai();
                        FormUtama.formNilai.clearjTable1();
                        
                        if (listNilai.length>0){
                            for (int i=0; i<listNilai.length;i++){
                                if (!((String)listNilai[i][0]).equals("")){
                                    String namaMataKuliah="";
                                    if (mataKuliah.baca((String)listNilai[i][0])){
                                        namaMataKuliah = mataKuliah.getNamaMataKuliah();
                                    }
                                    FormUtama.formNilai.setTambahNilai(new Object[]{listNilai[i][0],namaMataKuliah,listNilai[i][1],listNilai[i][2],listNilai[i][3]});
                                    jumlahNilai++;
                                }
                            }
                        }
                    }
                    
                    if (jumlahNilai==0) {
                        FormUtama.formNilai.setTambahNilai(new Object[]{});
                    }
                }  else {
                    JOptionPane.showMessageDialog(null, mahasiswa.getPesan());
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, mahasiswa.getPesan());
        }
    }
    
    public void tampilkanFormLihatMataKuliah(){
        formLihatMataKuliah = new FormLihatMataKuliah(null,true);
        if (mataKuliah.bacaData()){
            formLihatMataKuliah.tampilkanData(mataKuliah.getList());
            
            formLihatMataKuliah.setVisible(true);
            if (!formLihatMataKuliah.getKodeMataKuliahDipilih().equals("")){
                
                if (mataKuliah.baca(formLihatMataKuliah.getKodeMataKuliahDipilih())){
                    FormUtama.formNilai.setTambahNilai(new Object[]{mataKuliah.getKodeMataKuliah(),mataKuliah.getNamaMataKuliah(),"","",""});
                } else {
                    FormUtama.formNilai.setTambahNilai(new Object[]{formLihatMataKuliah.getKodeMataKuliahDipilih(),"","","",""});
                }
            }
        }  else {
            JOptionPane.showMessageDialog(null, mataKuliah.getPesan());
        }
    }
    
    public void cariMataKuliah(String kodeMataKuliah){
        if (mataKuliah.baca(kodeMataKuliah)){
            FormUtama.formNilai.setNamaMataKuliah( mataKuliah.getNamaMataKuliah());                      
        } else {
            FormUtama.formNilai.setNamaMataKuliah("");        
            FormUtama.formNilai.hapusNilai();
            
            JOptionPane.showMessageDialog(null, mataKuliah.getPesan(), "Kesalahan", JOptionPane.ERROR_MESSAGE);
        }    
    }
    
    public void simpan(javax.swing.JTextField nim, javax.swing.JTable jTable1){
	if (!nim.getText().equals("")){
            nilai.setNim(nim.getText());
            Object[][] listNilai = new Object[jTable1.getRowCount()][4];
            
            for (int i=0; i <jTable1.getRowCount();i++){
                listNilai[i][0] = jTable1.getValueAt(i, 0);
                listNilai[i][1] = jTable1.getValueAt(i, 2);
                listNilai[i][2] = jTable1.getValueAt(i, 3);
                listNilai[i][3] = jTable1.getValueAt(i, 4);
            }
            
            nilai.setListNilai(listNilai);            
            
            if (nilai.simpan()){
                FormUtama.formNilai.setNim("");
                FormUtama.formNilai.setNama("");
                FormUtama.formNilai.setSemester("");
                FormUtama.formNilai.setKelas("");
                FormUtama.formNilai.clearjTable1();
                FormUtama.formNilai.setTambahNilai(new Object[]{});
            }  else {
                JOptionPane.showMessageDialog(null, nilai.getPesan());
            }
        } else {
            JOptionPane.showMessageDialog(null,"nim tidak boleh kosong\n","Kesalahan",JOptionPane.ERROR_MESSAGE);
        }
    }    
    
    public void cetakLaporan(javax.swing.JComboBox jComboBox1,
            javax.swing.JComboBox jComboBox2){
        int semester=0;
        String kelas="";
        
        if (jComboBox1.getSelectedIndex()>0){
            semester = Integer.parseInt(jComboBox1.getSelectedItem().toString());
        }
        
        if (jComboBox2.getSelectedIndex()>0){
            kelas = jComboBox2.getSelectedItem().toString();
        }
        
        if (!nilai.cetakLaporan(semester, kelas)) {
            JOptionPane.showMessageDialog(null,nilai.getPesan(),"Kesalahan",JOptionPane.ERROR_MESSAGE);
        }
    }
}
